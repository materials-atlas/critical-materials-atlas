Silicon-to-chip study evidence tables
Critical Materials Atlas, 24 November 2026

The CSV files use UTF-8 and retain the values from the public evidence files.
Join the source column to sources.csv for titles and links.

fab_capacity_shares.csv: SIA/BCG Exhibit 7. Shares are percentages of
global capacity in 300 mm-equivalent wafer starts per month. Commercial
fabs below 200 mm or 5,000 monthly starts are excluded. The shares are
rounded. The 2025, 2030 and 2032 values are forecasts published in 2024.

fab_capacity_by_chip_type.csv: OECD operating capacity in September 2025.
Each chip type has its own ranking. Some fabs cover several types.

wafer_shipments.csv: SEMI global semiconductor-wafer shipments and nominal
revenues at published precision. SEMI excludes wafers for solar applications.

polysilicon_suppliers.csv: SIA identifies the companies and their home
economies. The table gives no facility geography or individual share.

silicon_trade.csv: CEPII BACI, V202601. China export shares are fractions
of world value, so 0.5 means 50%. The customs categories cover mixed products.
The table reports the article’s codes and does not allocate trade to chips.
